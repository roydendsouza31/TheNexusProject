import React, { useState, useEffect } from "react";
import { CookiesProvider, useCookies } from "react-cookie";
import Auth from "./components/Auth";
import ListHeader from "./components/ListHeader";
import ListItem from "./components/ListItem";

const App = () => {
  const [cookies, setCookie, removeCookie] = useCookies(null);
  const [user, setUser] = useState(cookies.Email || null);
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    // Fetch todos when the component mounts
    if (user) {
      getData();
    }
  }, [user]);

  const getData = async () => {
    try {
      const response = await fetch(`http://localhost:5000/todos/${user}`);
      const data = await response.json();
      setTodos(data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <CookiesProvider>
      <div className="App">
        {!user ? (
          <Auth setUser={setUser} />
        ) : (
          <>
            <ListHeader listName="To-Do List" getData={getData} />
            <ul className="todo-list">
              {todos.map((task) => (
                <ListItem key={task.id} task={task} getData={getData} />
              ))}
            </ul>
          </>
        )}
      </div>
    </CookiesProvider>
  );
};

export default App;

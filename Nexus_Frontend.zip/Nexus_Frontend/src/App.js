import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import MagicCard from "./components/MagicCard";
import Features from "./components/Features";
import Footer from "./components/Footer";
import Todolist from "./components/Todolist";
import ClassroomTask from "./components/ClassroomTask";
import PageNotFound from "./components/PageNotFound";

import {
  createBrowserRouter,
  RouterProvider,
  Route,
  createRoutesFromElements,
} from "react-router-dom";

const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route
        path="/"
        element={[
          <Navbar />,
          <Hero />,
          <MagicCard />,
          <Features />,
          <Footer />,
        ]}
      />
      <Route path="todolist" element={[<Navbar />, <Todolist />]} />
      <Route path="classroomtasks" element={[<Navbar />, <ClassroomTask />]} />
      <Route path="*" element={[<Navbar />, <PageNotFound />, <Footer />]} />
    </>
  )
);

function App() {
  return <RouterProvider router={router} />;
}

export default App;

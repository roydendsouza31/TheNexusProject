import React from "react";
import "./CSS/MagicCardStyles.css";
import { Link } from "react-router-dom";

const MagicCard = () => {
  return (
    <>
      <div class="container px-4 py-5" id="featured-3">
        <h2 class="pb-2 border-bottom">What we offer</h2>
        <div className="card-container pt-5">
          <div className="card">
            <p>To-Do List</p>
            <Link to="todolist">
              <button className="btn">Go!</button>
            </Link>
          </div>
          <div className="card">
            <p>Classroom Tasks</p>
            <Link to="classroomtasks">
              <button className="btn">Go!</button>
            </Link>
          </div>
          <div className="card">
            <p>Annual Planner</p>
            <Link to="annualplanner">
              <button className="btn">Go!</button>
            </Link>
          </div>
          <div className="card">
            <p>Classroom Progress</p>
            <Link to="classroomprogress">
              <button className="btn">Go!</button>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
};

export default MagicCard;

import React from "react";
import logo_transparent from "../assets/logo_transparent.png";
import { Link } from "react-router-dom";
export default function Navbar() {
  const logoStyle = {
    display: "flex",
    alignItems: "center",
  };

  const logoImgStyle = {
    marginRight: "10px", // Adjust the margin as needed
  };

  const linkStyle = {
    color: "white",
    textDecoration: "none",
  };

  function addHoverEffect(event) {
    event.target.style.color = "lightblue"; // Change the color on hover
  }

  function removeHoverEffect(event) {
    event.target.style.color = linkStyle.color;
  }

  return (
    <nav
      className="navbar navbar-expand-lg navbar-dark fixed-top"
      style={{ backgroundColor: "black", position: "relative", zIndex: 1 }}
    >
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          <div style={logoStyle}>
            <img
              src={logo_transparent}
              alt=""
              width="60"
              height="60"
              className="d-inline-block align-text-top"
              style={logoImgStyle}
            />
            <span style={{ fontFamily: "Playfair Display" }}>Nexus</span>
          </div>
        </Link>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarSupportedContent"
        >
          <ul className="nav">
            <li className="nav-item">
              <Link
                className="nav-link"
                aria-current="page"
                to="/"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className="nav-link"
                aria-current="page"
                to="docs"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Docs
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className="nav-link"
                to="download"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Download
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className="nav-link"
                to="about"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                About
              </Link>
            </li>
          </ul>
          <div class="text-end">
            <Link to="login">
              <button type="button" class="btn btn-outline-light me-2">
                Login
              </button>
            </Link>
            <Link to="signup">
              <button type="button" class="btn btn-warning">
                Sign-up
              </button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

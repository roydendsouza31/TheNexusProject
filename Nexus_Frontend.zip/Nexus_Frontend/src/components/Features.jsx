import calendarIcon from "../assets/calendar.svg";
import announcementIcon from "../assets/announcement.svg";
import progressIcon from "../assets/progress.svg";

export default function Features() {
  return (
    <div class="container px-4 py-5" id="featured-3">
      <h2 class="pb-2 border-bottom">Unleash the Power of Nexus</h2>
      <div class="row g-4 py-5 row-cols-1 row-cols-lg-3">
        <div class="feature col">
          <div class="feature-icon py-3">
            <img
              className="bi"
              src={calendarIcon}
              alt=""
              style={{ width: "2em", height: "2em" }}
            />
          </div>
          <h2>Efficient Task Management</h2>
          <p>
            Nexus simplifies task management for both teachers and students.
            Users can create to-do lists and set deadlines. Teachers can assign
            tasks, and students can keep track of their grades, making it easier
            to manage and complete tasks efficiently.
          </p>
        </div>
        <div class="feature col">
          <div class="feature-icon py-3">
            <img
              className="bi"
              src={progressIcon}
              alt=""
              style={{ width: "2em", height: "2em" }}
            />
          </div>
          <h2>Comprehensive Progress Tracking</h2>
          <p>
            The built-in chat application in Nexus fosters real-time
            communication between teachers and students. Teachers can use this
            platform to make important announcements, answer questions, and
            provide guidance. This feature encourages collaboration, enhances
            engagement, and keeps everyone informed about important updates and
            events.
          </p>
        </div>
        <div class="feature col">
          <div class="feature-icon py-3">
            <img
              className="bi"
              src={announcementIcon}
              alt=""
              style={{ width: "2em", height: "2em" }}
            />
          </div>
          <h2>Real-time Communication and Announcements</h2>
          <p>
            The chat application fosters communication between teachers and
            students. Teachers can use this platform to make announcements and
            answer questions. This feature encourages collaboration, enhances
            engagement, and keeps everyone informed about important updates.
          </p>
        </div>
      </div>
    </div>
  );
}

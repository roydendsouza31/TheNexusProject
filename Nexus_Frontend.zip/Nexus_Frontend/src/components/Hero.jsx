import website_screenshot from "../assets/website_screenshot.png";

export default function Hero() {
  return (
    <div class="container my-5">
      <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
        <div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
          <h1 class="display-4 fw-bold lh-1">
            Nexus: Your All-in-One Productivity Companion
          </h1>
          <p class="lead">
            Nexus is your ultimate solution for seamless collaboration and
            productivity in the classroom. Whether you're a teacher or a
            student, Nexus offers a wide range of tools to simplify your
            academic life.
          </p>
        </div>
        <div class="col-lg-4 offset-lg-1 p-0 overflow-hidden shadow-lg">
          <img
            class="rounded-lg-3"
            src={website_screenshot}
            alt=""
            width="720"
          />
        </div>
      </div>
    </div>
  );
}

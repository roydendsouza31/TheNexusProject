import logo from "../assets/logo_transparent.png";
import { Link } from "react-router-dom";
import "../index.css";
export default function Footer() {
  const linkStyle = {
    color: "white",
    textDecoration: "none",
  };

  function addHoverEffect(event) {
    event.target.style.color = "lightblue"; // Change the color on hover
  }

  function removeHoverEffect(event) {
    event.target.style.color = linkStyle.color;
  }
  return (
    <div id="footer" class="container-fluid">
      <footer
        class="row  row-cols-4 py-5 px-3 mt-1 "
        style={{
          backgroundColor: "black",
          color: "white",
        }}
      >
        <div class="col">
          <Link
            to="/"
            class="d-flex align-items-center mb-3 text-decoration-none"
          >
            <img width="50" height="50" src={logo} alt="" />
            <svg class="bi me-2" width="40" height="32"></svg>
          </Link>
          <p>© 2023</p>
        </div>

        <div class="col"></div>

        <div class="col">
          <ul class="nav flex-column">
            <li class="nav-item mb-2">
              <Link
                to="/"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Home
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="features"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Features
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="pricing"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Pricing
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="faqs"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                FAQs
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="about"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                About
              </Link>
            </li>
          </ul>
        </div>

        <div class="col">
          <ul class="nav flex-column">
            <li class="nav-item mb-2">
              <Link
                to="team"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Team
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="privacy"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Privacy
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="business"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Business
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="education"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Education
              </Link>
            </li>
            <li class="nav-item mb-2">
              <Link
                to="support"
                class="nav-link p-0"
                style={linkStyle}
                onMouseEnter={addHoverEffect}
                onMouseLeave={removeHoverEffect}
              >
                Support
              </Link>
            </li>
          </ul>
        </div>
      </footer>
    </div>
  );
}
